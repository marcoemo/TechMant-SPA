package com.example.GestionSolicitudes;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GestionSolicitudesApplication {

	public static void main(String[] args) {
		SpringApplication.run(GestionSolicitudesApplication.class, args);
	}

}
