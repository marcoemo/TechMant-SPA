package com.example.GestionSolicitudes;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GestionSolicitudesApplicationTests {

	@Test
	void contextLoads() {
	}

}
